# Preprint source

Build preprint/Preprint.tex and supplement/SupplementaryInformation.tex from their own directories with Tectonic or XeLaTeX. The shared Article sources, diagrams and supplemental figure are included.
