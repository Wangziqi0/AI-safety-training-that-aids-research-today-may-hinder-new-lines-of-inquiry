# Manuscript source

Build article/Article.tex from its own directory and supplement/SupplementaryInformation.tex from its own directory using Tectonic or XeLaTeX with Liberation Serif. The relative layout is required.
